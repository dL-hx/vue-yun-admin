<template>
  <div id="app">
    <div id="nav">
      <!-- 路由出口 -->
    </div>
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>
<style lang="less">
</style>
