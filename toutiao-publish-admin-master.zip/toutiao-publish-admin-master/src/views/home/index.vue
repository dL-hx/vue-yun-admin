<template>
  <div>
    首页
  </div>
</template>
<script>
export default {
  name: 'HomeIndex', // 方便调试和查找，不要重复
  data () {
    return {}
  },
  created () {
  },
  methods: {}
}
</script>
<style lang="less" scoped>
</style>
